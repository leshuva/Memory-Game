﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace HanoiTowers1
{
    /// <summary>
    /// Holds list of stored games. Allows chossing a stored game to load
    /// </summary>
    public partial class HistoryForm : Form
    {
        //Game logic container
        private Board _board;
        //stored games
        private ArrayList _historyRecords;
        //chosen game to load
        private HistoryRecord _historyRecord;
        /// <summary>
        /// Gets chosen stored game
        /// </summary>
        public HistoryRecord GameMoves
        {
            get { return _historyRecord; }
        }

        /// <summary>
        /// Constructor for HistoryForm. Takes Board object as a parameter.
        /// </summary>
        /// <param name="board"></param>
        public HistoryForm(Board board)
        {
            InitializeComponent();

            _board = board;

            this.Load += new EventHandler(HistoryForm_Load);
            btnCancel.Click += new EventHandler(Cancel_Click);
            btnReplay.Click += new EventHandler(Load_Click);
        }

        //On a form load even gets stored games from a file by using _board object
        //fills list box with stored games
        private void HistoryForm_Load(object sender, EventArgs e)
        {
            _historyRecords = _board.UploadHistory();

            lbxHistory.DataSource = _historyRecords;
        }

        //Marks selected strored game as chosen history record and closes the form
        private void Load_Click(object sender, EventArgs e)
        {

            if (lbxHistory.SelectedItem == null)
            {
                MessageBox.Show("Please choose one game to upload");
                return;
            }

            _historyRecord = (lbxHistory.SelectedItem as HistoryRecord);

            this.Close();
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
