﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace HanoiTowers1
{
    /// <summary>
    /// Store information of one game
    /// </summary>
    public class HistoryRecord
    {
        //Name of a game
        private string _name = "";
        //is game successful or not
        private bool _isSuccess = false;
        //stored array list of moves
        private ArrayList _moves = new ArrayList();

        /// <summary>
        /// Gets name of a stored game
        /// </summary>
        public string Name
        {
            get { return _name; }
        }

        /// <summary>
        /// Gets whether a stored game is successful or not
        /// </summary>
        public bool IsSuccess
        {
            get { return _isSuccess; }
        }

        /// <summary>
        /// Gets array list of moves in a stored game
        /// </summary>
        public ArrayList Moves
        {
            get { return _moves; }
        }

        /// <summary>
        /// Constructor of a HistoryRecord
        /// </summary>
        /// <param name="name"></param>
        /// <param name="isSuccess"></param>
        /// <param name="moves"></param>
        public HistoryRecord(string name, bool isSuccess, ArrayList moves)
        {
            _name = name;
            _isSuccess = isSuccess;
            _moves = moves;
        }

        /// <summary>
        /// Overriden ToString method to show history records in a list box
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            if (IsSuccess)
            {
                return _name + " " + Board.GAME_END;
            }
            else
            {
                return _name;
            }
        }

    }
}
