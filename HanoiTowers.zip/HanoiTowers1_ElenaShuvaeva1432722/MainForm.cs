﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace HanoiTowers1
{
    /// <summary>
    /// Main form of a game. Shows game board, disks, pegs, and some information about a game
    /// Allows loading stored games, drag and drop disks from one peg to another
    /// </summary>
    public partial class MainForm : Form
    {
        //Main game logic object
        private Board _board;

        //used to communicate between DragDrop which identifies the pole being dropped on
        //and the MouseDown method for the "disks" which will move a "disk" to a new
        //pole after DragDrop is completed
        private int _targetPeg = 0;
        //Disk that is being dragged at the moment
        private Disk _draggedDisk;
        /// <summary>
        /// MainForm constructor
        /// </summary>
        public MainForm()
        {
            InitializeComponent();

            int initialPeg = 0;

            Disk d1 = new Disk(disk1,initialPeg,0);
            Disk d2 = new Disk(disk2,initialPeg,1);
            Disk d3 = new Disk(disk3,initialPeg,2);
            Disk d4 = new Disk(disk4,initialPeg,3);

            _board = new Board(d1, d2, d3, d4);

            disk1.MouseDown += new MouseEventHandler(Disk_MouseDown);
            disk2.MouseDown += new MouseEventHandler(Disk_MouseDown);
            disk3.MouseDown += new MouseEventHandler(Disk_MouseDown);
            disk4.MouseDown += new MouseEventHandler(Disk_MouseDown);

            peg1.DragEnter += new DragEventHandler(Peg_DragEnter);
            peg2.DragEnter += new DragEventHandler(Peg_DragEnter);
            peg3.DragEnter += new DragEventHandler(Peg_DragEnter);

            btnReset.Click += new EventHandler(Reset_Click);

            btnShowHistory.Click += new EventHandler(Load_Click);

            this.Load += new EventHandler(MainForm_Load);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //assign current form link to a _board object in order to show some game logic from internal code of a Board object
            _board.MainForm = this;
        }

        // Shows HistoryForm window, if a game was chosen on a history form, then it uploads a stored game to a board
        private void Load_Click(object sender, EventArgs e)
        {

            HistoryForm hf = new HistoryForm(_board);
            hf.ShowDialog();
            if (hf.GameMoves != null)
            {
                _board.LoadHistory(hf.GameMoves);
            }

        }
        // Starts game from a beginning
        private void Reset_Click(object sender, EventArgs e)
        {

            _board.ResetGame();
            lblMoves.Text = _board.MovesCount.ToString();
            tbHistory.Text = "";
        }


        private void GetPegIndex(Label pegLabel)
        {
            if (pegLabel == peg1)
            {
                _targetPeg = 0;
            }
            else if (pegLabel == peg2)
            {
                _targetPeg = 1;
            }
            else if (pegLabel == peg3)
            {
                _targetPeg = 2;
            }
        }

        private void Peg_DragEnter(object sender, DragEventArgs e)
        {
            Label pegLabel = (sender as Label);

            //Check if it is possible to drop
            this.GetPegIndex(pegLabel);

            if (_board.CanDrop(_draggedDisk, _targetPeg))
            {
                e.Effect = DragDropEffects.All;
            }
        }

        private void Disk_MouseDown(object sender, MouseEventArgs e)
        {
            Label diskLabel = (sender as Label);
            _draggedDisk = _board.FindDisk(diskLabel);

            //Check if it is valid to use this disk
            if (!_board.CanStartMove(_draggedDisk))
            {
                MessageBox.Show("Only the top Disk on a peg can move.");
                return;
            }

            DragDropEffects result = diskLabel.DoDragDrop(diskLabel, DragDropEffects.All);
            if (result != DragDropEffects.None)
            {
                _board.Move(_draggedDisk, _targetPeg);

                this.RefreshGameCounters();

                if (_board.IsGameFinished())
                {
                    string greeting = "";

                    if (_board.IsMinimumNumberOfMoves())
                    {
                        greeting = "You have successfully completed the game with the minimum number of moves";
                    }
                    else
                    {
                        greeting = "You have successfully completed the game but not with the minimum number of moves";
                    }

                    MessageBox.Show(greeting);
                }

            }

        }

        /// <summary>
        /// Refreshes displayed values in moves count label and in history list box
        /// </summary>
        public void RefreshGameCounters()
        {
            lblMoves.Text = _board.MovesCount.ToString();
            tbHistory.Text = _board.AllMovesAsString();
        }

        /// <summary>
        /// Enable/disable buttons for animation demonstration
        /// </summary>
        /// <param name="prepare">true - disable buttons on the form, false - enable</param>
        public void PrepareForAnimation(bool prepare)
        {
            foreach (Control control in this.Controls)
            {
                control.Enabled = !prepare;
            }

        }
    }
}
