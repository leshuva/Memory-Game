﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using System.IO;

namespace HanoiTowers1
{
    /// <summary>
    /// This class represents playing board and it is responsible for storing game's constants, 
    /// keeping game's history and actual game's position
    /// </summary>
    public class Board
    {

        public static readonly int MAX_POLES = 3;
        public static readonly int DISKS_NUMBER = 4;
        public static readonly int POLE_START = 238;
        public static readonly int POLE_GAP = 180;
        public static readonly int DECK_HEIGHT = 143;
        public static readonly int DISK_HEIGHT = 24;

        public static readonly string COUNT_MOVES_FILE = "MovesCount.txt";
        public static readonly string STORED_GAMES_FILE = "StoredGames.txt";

        public static readonly string GAME_DELIMITER = "#########";
        public static readonly string GAME_PREFIX = "Hanoi";
        public static readonly string GAME_END = "Success";

        // Describes position of a disk on a peg 
        // first index is for peg - from 0 to MAX_POLES (MAX_POLES - 1) - from left to right
        // second is for a disk position on a peg - from 0 to DISKS_NUMBER (DISKS_NUMBER - 1) - from top to bottom
        private Disk[,] _diskPositions = new Disk[MAX_POLES, DISKS_NUMBER];
        // Keeps collection of current moves
        private ArrayList _moves = new ArrayList();
        // Keeps collection of moves strored in a loaded game
        private ArrayList _storedMoves = new ArrayList();
        //Array of disks
        private Disk[] _disks;
        //Flag that helps to run different logic when game is being replayed through animation - all previously played successful games
        private bool _isReplay = false;

        //Timer to play animation
        private System.Windows.Forms.Timer _timer = new Timer();
        //Index of a currently run animation step
        private int _currentMoveIndex = 0;

        //Contains link to MainForm in order to control some form behaviour
        private MainForm _mainForm;

        /// <summary>
        /// Gets and Sets MainForm
        /// </summary>
        public MainForm MainForm
        {
            get { return _mainForm; }
            set { _mainForm = value; }
        }
        /// <summary>
        /// Gets amount of moves played in a game
        /// </summary>
        public int MovesCount
        {
            get { return _moves.Count; }
        }

        /// <summary>
        /// Constructor of Board class
        /// </summary>
        /// <param name="d1"></param>
        /// <param name="d2"></param>
        /// <param name="d3"></param>
        /// <param name="d4"></param>
        public Board(Disk d1, Disk d2, Disk d3, Disk d4)
        {
            _disks = new Disk[] { d1, d2, d3, d4 };

            _timer.Interval = 1000; // 1 sec
            _timer.Tick += new EventHandler(Timer_Tick);

            //Start by placing all disks on left peg as if resetting game
            this.ResetGame();


        }

        /// <summary>
        /// Reset the game to the beginning
        /// </summary>
        public void ResetGame()
        {
            //Start new game and therefore write new stored game
            if (!_isReplay)
            {
                StartStoreGame();
            }
            //Refresh disk positions on a board
            _diskPositions = new Disk[MAX_POLES, DISKS_NUMBER];

            int leftPegPositionIndex = 0;
            // Put disks on a left peg with smallest disk (index 0) on a top and biggest (index 3) on a bottom
            for (int diskIndex = 0; diskIndex < _disks.Length; diskIndex++)
            {
                _diskPositions[leftPegPositionIndex, diskIndex] = _disks[diskIndex];
            }

            //There are no actual movements so all disks are just resetted to their initial places
            foreach (Disk d in _disks)
            {
                d.Reset();
            }

            this.Display();

            _moves.Clear();
        }

        //Start saving a game
        private void StartStoreGame()
        {
            string gameName = GAME_PREFIX + " " + DateTime.Now.ToString();
            bool append = true;
            StreamWriter sr = new StreamWriter(STORED_GAMES_FILE, append);
            sr.WriteLine(GAME_DELIMITER);
            sr.WriteLine(gameName);
            sr.Close();
        }


        /// <summary>
        /// Check if it is valid to begin a move with a particular Disk (only the top Disk on a peg can move)
        /// </summary>
        /// <param name="aDisk"></param>
        /// <returns></returns>
        public bool CanStartMove(Disk aDisk)
        {
            bool result = true;

            for (int diskLevelIndex = 0; diskLevelIndex < aDisk.Level; diskLevelIndex++)
            {
                if (_diskPositions[aDisk.Peg, diskLevelIndex] != null) // There is a disk above the one that is being moved 
                {
                    result = false;
                }
            }

            return result;
        }


        /// <summary>
        /// Check if it is valid to drop a particular disk on a Peg (drops are only allowed for a Disk 
        /// that is smaller than the top Disk on a peg or for an empty peg)
        /// </summary>
        /// <param name="aDisk"></param>
        /// <param name="aPeg">Index of a peg where to put the disk</param>
        /// <returns></returns>
        public bool CanDrop(Disk aDisk, int aPeg)
        {
            for (int diskIndex = 0; diskIndex < _disks.Length; diskIndex++)
            {
                if (
                    aDisk.Peg == aPeg // Do not drop on the same Peg
                    ||
                    (_diskPositions[aPeg, diskIndex] != null
                    &&
                    _diskPositions[aPeg, diskIndex].Diameter < aDisk.Diameter)
                    )
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Move a disk to a new Peg.
        /// Save a DiskMove object representing the latest move to the ArrayList of moves
        /// </summary>
        /// <param name="aDisk"></param>
        /// <param name="newPeg"></param>
        public void Move(Disk aDisk, int newPeg)
        {
            // This logic is already in MainForm class, but because there could be different ways of showing the game, 
            // the logic should be consitent inside game objects
            if (!(this.CanStartMove(aDisk) && this.CanDrop(aDisk, newPeg)))
            {
                return;
            }
            //find min free level to put the disk on
            int diskPosition = 0;
            for (int diskIndex = 1; diskIndex < _disks.Length; diskIndex++)
            {
                if (_diskPositions[newPeg, diskIndex] == null)
                {
                    diskPosition = diskIndex;
                }
            }

            int initialDiskPosition = aDisk.Level;
            _diskPositions[aDisk.Peg, aDisk.Level] = null;

            aDisk.Peg = newPeg;
            aDisk.Level = diskPosition;

            _diskPositions[aDisk.Peg, aDisk.Level] = aDisk;

            this.Display();

            //Save a DiskMove object representing the latest move to the ArrayList of moves
            DiskMove movement = new DiskMove(aDisk.DiskNumber, newPeg);
            _moves.Add(movement);

            if (_mainForm != null)
            {
                _mainForm.RefreshGameCounters();
            }

            if (!_isReplay)
            {
                StoreMovement(movement);
            }
        }

        /// <summary>
        /// Return a string giving the moves so far, one move per line.
        /// </summary>
        /// <returns></returns>
        public string AllMovesAsString()
        {
            string result = "";

            foreach (object moveObj in _moves)
            {
                DiskMove move = moveObj as DiskMove;
                result += move.AsText() + "\r\n";
            }


            return result;
        }

        /// <summary>
        /// Display the current position of the disks. 
        /// This is done by changing the Top and Left properties of the disks which in turn changes where the labels show on the screen.
        /// </summary>
        public void Display()
        {
            foreach(Disk disk in _disks)
            {
                disk.DiskLabel.Hide();
                disk.DiskLabel.Left = Board.POLE_START + ((disk.Peg) * Board.POLE_GAP) - (disk.Diameter / 2);
                disk.DiskLabel.Top = Board.DECK_HEIGHT + ((disk.Level + 1) * Board.DISK_HEIGHT); 
                disk.DiskLabel.Show();
            }

        }

        /// <summary>
        /// Get a reference to the disk that matches a label. 
        /// This is to be used to find which disk object is being dragged on the form.
        /// </summary>
        /// <param name="aLabel"></param>
        /// <returns></returns>
        public Disk FindDisk(Label aLabel)
        {

            Disk result = null;

            foreach (Disk disk in _disks)
            {
                if (disk.DiskLabel == aLabel)
                {
                    result = disk;
                }
            }

            return result;
        }

        /// <summary>
        /// Checks if all disks are on the right peg
        /// According to the ruls it is impossible if the disks are in incorrect order on a peg,
        /// so only need to check if the peg contains all 4 disks
        /// </summary>
        /// <returns></returns>
        public bool IsGameFinished()
        {
            bool result = true;

            int rightPegIndex = 2;

            for (int diskIndex = 0; diskIndex < _disks.Length; diskIndex++)
            {
                if (_diskPositions[rightPegIndex, diskIndex] == null)
                {
                    result = false;
                }
            }

            //If it is the last movement then save number of moves to keep track of them, 
            //to show if it was minimum number of moves
            if (result)
            {
                SaveNumberOfMoves(_moves.Count);
                StoreGameSuccess();
            }
            
            return result;
        }

        /// <summary>
        /// Checks if a game was played with minimum number of moves in comparison with all previously run games
        /// It is done by reading from a file with stored number of moves from previous games
        /// </summary>
        /// <returns></returns>
        public bool IsMinimumNumberOfMoves()
        {
            bool result = false;

            StreamReader sr = null;
            try
            {
                sr = new StreamReader(COUNT_MOVES_FILE);
                string contents = sr.ReadToEnd();
                string[] lines = contents.Split(new string[] { "\r\n" }, StringSplitOptions.None);


                int minMovementsCount = 0;
                //Assume that minimum number is in first line
                //If there is no number in first line than no number was stored so it is minimum
                if (lines.Length > 0 && Int32.TryParse(lines[0], out minMovementsCount))
                {
                    //Start with second line because first was already used
                    for (int lineIndex = 1; lineIndex < lines.Length; lineIndex++)
                    {
                        string line = lines[lineIndex];
                        int movesCount;
                        //if number in next line is smaller than current min number then 
                        //next line number becomes new min number
                        if (Int32.TryParse(line, out movesCount)
                            &&
                            movesCount < minMovementsCount
                            )
                        {
                            minMovementsCount = movesCount;
                        }
                    }
                }
                else
                {
                    result = true;
                }
                if (minMovementsCount != 0 && minMovementsCount >= _moves.Count)
                {
                    result = true;
                }

            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File " + COUNT_MOVES_FILE + " not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("File " + COUNT_MOVES_FILE + " cannot be read: " + ex.Message);
            }
            catch (OutOfMemoryException ex)
            {
                MessageBox.Show("Not enough memory to read information from file " + COUNT_MOVES_FILE + " Messsage: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected exception appeared during reading from file " + COUNT_MOVES_FILE + " Messsage: " + ex.Message);
            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                }
            }


            return result;
        }

        //Allows to keep track of number of moves for a user.
        private void SaveNumberOfMoves(int movesCount)
        {
            bool appendToFile = true;
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(COUNT_MOVES_FILE, appendToFile);
                sw.WriteLine(movesCount);
                sw.Flush();
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File " + COUNT_MOVES_FILE + " not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("Impossible to write into file " + COUNT_MOVES_FILE + " Message: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected exception appeared during writing into file " + COUNT_MOVES_FILE + " Messsage: " + ex.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }

        //Store single movement
        private void StoreMovement(DiskMove movement)
        {
            bool append = true;
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(STORED_GAMES_FILE, append);
                sw.WriteLine(movement.AsText());
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File " + STORED_GAMES_FILE + " not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("Impossible to write into file " + STORED_GAMES_FILE + " Message: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected exception appeared during writing into file " + STORED_GAMES_FILE + " Messsage: " + ex.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }

        //Store success lable in a stored games file in order to choose a game for animation
        private void StoreGameSuccess()
        {
            bool append = true;
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(STORED_GAMES_FILE, append);
                sw.WriteLine(GAME_END);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File " + STORED_GAMES_FILE + " not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("Impossible to write into file " + STORED_GAMES_FILE + " Message: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected exception appeared during writing into file " + STORED_GAMES_FILE + " Messsage: " + ex.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }

        //Save a game
        private void StoreGame()
        {
            bool append = true;
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(STORED_GAMES_FILE, append);

                foreach (object line in _moves)
                {
                    string movement = (line as DiskMove).AsText();
                    sw.WriteLine(movement);
                }
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File " + STORED_GAMES_FILE + " not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("Impossible to write into file " + STORED_GAMES_FILE + " Message: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected exception appeared during writing into file " + STORED_GAMES_FILE + " Messsage: " + ex.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }

        /// <summary>
        /// Gets previously stored games from file
        /// </summary>
        /// <returns></returns>
        public ArrayList UploadHistory()
        {
            ArrayList history = new ArrayList();

            
            StreamReader sr = null;
            try
            {
                sr = new StreamReader(STORED_GAMES_FILE);
                string contents = sr.ReadToEnd();

                string[] games = contents.Split(new string[] { GAME_DELIMITER }, StringSplitOptions.None);

                foreach (string game in games)
                {

                    if (game != "") //No need for empty games
                    {
                        string[] movements = game.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

                        if (movements.Length > 1)
                        {
                            ArrayList moves = new ArrayList();

                            //first line is for game name
                            string name = movements[0];

                            bool isSuccess = false;

                            for (int lineIndex = 1; lineIndex < movements.Length; lineIndex++)
                            {
                                if (movements[lineIndex] != GAME_END)
                                {
                                    moves.Add(new DiskMove(movements[lineIndex]));
                                }
                                else
                                {
                                    isSuccess = true;
                                }
                            }

                            HistoryRecord hr = new HistoryRecord(name, isSuccess, moves);
                            history.Add(hr);
                        }
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File " + STORED_GAMES_FILE + " not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("File " + STORED_GAMES_FILE + " cannot be read: " + ex.Message);
            }
            catch (OutOfMemoryException ex)
            {
                MessageBox.Show("Not enough memory to read information from file " + STORED_GAMES_FILE + " Messsage: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected exception appeared during reading from file " + STORED_GAMES_FILE + " Messsage: " + ex.Message);
            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                }
            }
            return history;
        }

        /// <summary>
        /// Loads previously stored game as set of DiskMoves
        /// </summary>
        /// <param name="gameMoves"></param>
        public void LoadHistory(HistoryRecord game)
        {
            _storedMoves = game.Moves;
            if (game.IsSuccess)
            {
                _isReplay = true;
                this.ReplayGame();
            }
            else
            {
                _isReplay = false;
                this.RestoreGame();
            }
        }
        //If a game is not successul, then no animation is played. A game is restored on a last step done previously
        private void RestoreGame()
        {
            this.ResetGame();

            foreach (DiskMove move in _storedMoves)
            {
                Disk disk = _disks[move.DiskIndex];

                this.Move(disk, move.PegIndex);
            }
            _storedMoves.Clear();
        }

        //If a game is successul, then animaion is started to play.
        private void ReplayGame()
        {
            this.ResetGame();


            if (_mainForm != null)
            {
                _mainForm.PrepareForAnimation(true);
            }

            _currentMoveIndex = 0;
            _timer.Start();
        }

        //Animation of a successful game is controlled by a timer. On a timer tick event one dsk is moved.
        // If a step is a last one then timer is stopped
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (_currentMoveIndex < _storedMoves.Count)
            {
                DiskMove move = _storedMoves[_currentMoveIndex] as DiskMove;
                Disk disk = _disks[move.DiskIndex];

                this.Move(disk, move.PegIndex);

                _currentMoveIndex++;
            }
            else
            {
                _timer.Stop();
                _storedMoves.Clear();
                _isReplay = false;
                if (_mainForm != null)
                {
                    _mainForm.PrepareForAnimation(false);
                }

            }
        }

    }
}
