using System;
using System.Windows.Forms;
using System.Drawing;

namespace HanoiTowers1
{
	//the Disk class stores the pole and level of a label representing the disk
	//as well as an object refrence to the label
	public class Disk
	{
		
		private int _pole;
		private int _level;

        private int _initialPole;
        private int _initialLevel;

        
        private int _diameter;
		private Label _diskLabel;

        private int _diskNumber;

        private Color _color;

        /// <summary>
        /// Gets label of the disk
        /// </summary>
        public Label DiskLabel
        {
            get { return _diskLabel; }
        }

        /// <summary>
        /// Gets width of the disk
        /// </summary>
        public int Diameter
        {
            get { return _diameter; }
        }

        /// <summary>
        /// Gets and sets current peg position
        /// </summary>
        public int Peg
        {
            get { return _pole; }
            set { _pole = value; }
        }

        /// <summary>
        /// Gets and sets current level position
        /// Smaller level means higher disk position on a peg
        /// </summary>
        public int Level
        {
            get { return _level; }
            set { _level = value; }
        }

        /// <summary>
        /// Gets disk number
        /// </summary>
        public int DiskNumber
        {
            get { return _diskNumber; }
        }

        /// <summary>
        /// Gets colour of a disk
        /// </summary>
        public Color DiskColor
        {
            get { return _color; }
        }


	/// <summary>
	/// Constructor
	/// </summary>
	/// <param name="aLabel"></param>
	/// <param name="aPole"></param>
	/// <param name="aLevel"></param>
		public Disk(Label aLabel, int aPole, int aLevel)
		{
			_diameter = aLabel.Width;
            _color = aLabel.BackColor;
			_pole = aPole;
            _initialPole = aPole;
			_level = aLevel;
            _initialLevel = aLevel;
            _diskLabel = aLabel;

            _diskNumber = aLevel;
		}

        /// <summary>
        /// Returns to initial position
        /// </summary>
        public void Reset()
        {
            _pole = _initialPole;
            _level = _initialLevel;
        }
	
	}
}
