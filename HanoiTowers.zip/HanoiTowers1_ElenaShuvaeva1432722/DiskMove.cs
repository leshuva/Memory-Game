﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace HanoiTowers1
{
    /// <summary>
    /// Store the index of the disk making the move and the new Peg it is dropped on
    /// </summary>
    public class DiskMove
    {

        public static readonly char STRING_MOVE_SEPARATOR = ',';

        private int _diskIndex;
        private int _pegIndex;

        /// <summary>
        /// Gets index of a disk that is being moved
        /// </summary>
        public int DiskIndex
        {
            get { return _diskIndex; }
        }

        /// <summary>
        /// Gets index of a destination peg 
        /// </summary>
        public int PegIndex
        {
            get { return _pegIndex; }
        }

        /// <summary>
        /// Constructor for DiskMove class
        /// Takes two arguments - index of a disk to move and target peg index
        /// </summary>
        /// <param name="diskIndex"></param>
        /// <param name="pegIndex"></param>
        public DiskMove(int diskIndex, int pegIndex)
        {
            _diskIndex = diskIndex;
            _pegIndex = pegIndex;
        }

        /// <summary>
        /// Takes a string in the form “2,1” as a parameter
        /// </summary>
        /// <param name="stringMove">string in form of "[onenumber],[another number]"</param>
        public DiskMove(string stringMove)
        {
            string[] substrings = stringMove.Split(STRING_MOVE_SEPARATOR);

            if (!(substrings.Length == 2
                &&
                (Int32.TryParse(substrings[0], out _diskIndex) && Int32.TryParse(substrings[1], out _pegIndex)))
                )
            {
                MessageBox.Show("Incorrect parameter in DiskMove constructor: " + stringMove);
            }
        }


        /// <summary>
        /// Gives this information as a string, e.g. “1,2” means that Disk1 moved to peg2
        /// </summary>
        /// <returns></returns>
        public string AsText()
        {
            string result = _diskIndex + STRING_MOVE_SEPARATOR.ToString() + _pegIndex;
            return result;
        }


    }
}
