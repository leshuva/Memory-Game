﻿namespace HanoiTowers1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMoves = new System.Windows.Forms.Label();
            this.timer1 = new System.Timers.Timer();
            this.tbHistory = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.disk1 = new System.Windows.Forms.Label();
            this.disk2 = new System.Windows.Forms.Label();
            this.disk3 = new System.Windows.Forms.Label();
            this.disk4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.peg1 = new System.Windows.Forms.Label();
            this.peg2 = new System.Windows.Forms.Label();
            this.peg3 = new System.Windows.Forms.Label();
            this.btnShowHistory = new System.Windows.Forms.Button();
            this.lblhistory = new System.Windows.Forms.Label();
            this.lblDiscNPegN = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMoves
            // 
            this.lblMoves.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblMoves.Location = new System.Drawing.Point(378, 39);
            this.lblMoves.Name = "lblMoves";
            this.lblMoves.Size = new System.Drawing.Size(48, 24);
            this.lblMoves.TabIndex = 32;
            this.lblMoves.Text = "0";
            // 
            // timer1
            // 
            this.timer1.Interval = 500D;
            this.timer1.SynchronizingObject = this;
            // 
            // tbHistory
            // 
            this.tbHistory.Location = new System.Drawing.Point(738, 39);
            this.tbHistory.Multiline = true;
            this.tbHistory.Name = "tbHistory";
            this.tbHistory.ReadOnly = true;
            this.tbHistory.Size = new System.Drawing.Size(136, 280);
            this.tbHistory.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(290, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 40);
            this.label1.TabIndex = 28;
            this.label1.Text = "Moves:";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(26, 39);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(104, 32);
            this.btnReset.TabIndex = 24;
            this.btnReset.Text = "Reset";
            // 
            // disk1
            // 
            this.disk1.BackColor = System.Drawing.Color.Lime;
            this.disk1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.disk1.Location = new System.Drawing.Point(215, 167);
            this.disk1.Name = "disk1";
            this.disk1.Size = new System.Drawing.Size(48, 24);
            this.disk1.TabIndex = 23;
            this.disk1.Text = "0";
            this.disk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // disk2
            // 
            this.disk2.BackColor = System.Drawing.Color.Lime;
            this.disk2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.disk2.Location = new System.Drawing.Point(199, 191);
            this.disk2.Name = "disk2";
            this.disk2.Size = new System.Drawing.Size(80, 24);
            this.disk2.TabIndex = 22;
            this.disk2.Text = "1";
            this.disk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // disk3
            // 
            this.disk3.BackColor = System.Drawing.Color.Lime;
            this.disk3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.disk3.Location = new System.Drawing.Point(183, 215);
            this.disk3.Name = "disk3";
            this.disk3.Size = new System.Drawing.Size(112, 24);
            this.disk3.TabIndex = 21;
            this.disk3.Text = "2";
            this.disk3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // disk4
            // 
            this.disk4.BackColor = System.Drawing.Color.Lime;
            this.disk4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.disk4.Location = new System.Drawing.Point(167, 239);
            this.disk4.Name = "disk4";
            this.disk4.Size = new System.Drawing.Size(144, 24);
            this.disk4.TabIndex = 20;
            this.disk4.Text = "3";
            this.disk4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(130, 263);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(584, 48);
            this.panel1.TabIndex = 19;
            // 
            // peg1
            // 
            this.peg1.AllowDrop = true;
            this.peg1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.peg1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.peg1.Location = new System.Drawing.Point(226, 135);
            this.peg1.Name = "peg1";
            this.peg1.Size = new System.Drawing.Size(24, 144);
            this.peg1.TabIndex = 26;
            this.peg1.Text = "0";
            this.peg1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // peg2
            // 
            this.peg2.AllowDrop = true;
            this.peg2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.peg2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.peg2.Location = new System.Drawing.Point(407, 135);
            this.peg2.Name = "peg2";
            this.peg2.Size = new System.Drawing.Size(24, 144);
            this.peg2.TabIndex = 25;
            this.peg2.Text = "1";
            this.peg2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // peg3
            // 
            this.peg3.AllowDrop = true;
            this.peg3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.peg3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.peg3.Location = new System.Drawing.Point(586, 135);
            this.peg3.Name = "peg3";
            this.peg3.Size = new System.Drawing.Size(24, 144);
            this.peg3.TabIndex = 27;
            this.peg3.Text = "2";
            this.peg3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnShowHistory
            // 
            this.btnShowHistory.Location = new System.Drawing.Point(26, 89);
            this.btnShowHistory.Name = "btnShowHistory";
            this.btnShowHistory.Size = new System.Drawing.Size(104, 32);
            this.btnShowHistory.TabIndex = 33;
            this.btnShowHistory.Text = "Show history";
            // 
            // lblhistory
            // 
            this.lblhistory.AutoSize = true;
            this.lblhistory.Location = new System.Drawing.Point(734, 9);
            this.lblhistory.Name = "lblhistory";
            this.lblhistory.Size = new System.Drawing.Size(156, 13);
            this.lblhistory.TabIndex = 34;
            this.lblhistory.Text = "History of moves (current game)";
            // 
            // lblDiscNPegN
            // 
            this.lblDiscNPegN.AutoSize = true;
            this.lblDiscNPegN.Location = new System.Drawing.Point(735, 23);
            this.lblDiscNPegN.Name = "lblDiscNPegN";
            this.lblDiscNPegN.Size = new System.Drawing.Size(78, 13);
            this.lblDiscNPegN.TabIndex = 35;
            this.lblDiscNPegN.Text = "DiscNo,PegNo";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 358);
            this.Controls.Add(this.lblDiscNPegN);
            this.Controls.Add(this.lblhistory);
            this.Controls.Add(this.btnShowHistory);
            this.Controls.Add(this.lblMoves);
            this.Controls.Add(this.tbHistory);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.disk1);
            this.Controls.Add(this.disk2);
            this.Controls.Add(this.disk3);
            this.Controls.Add(this.disk4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.peg1);
            this.Controls.Add(this.peg2);
            this.Controls.Add(this.peg3);
            this.Name = "MainForm";
            this.Text = "Hanoi Towers";
            ((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMoves;
        private System.Timers.Timer timer1;
        private System.Windows.Forms.TextBox tbHistory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label disk1;
        private System.Windows.Forms.Label disk2;
        private System.Windows.Forms.Label disk3;
        private System.Windows.Forms.Label disk4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label peg1;
        private System.Windows.Forms.Label peg2;
        private System.Windows.Forms.Label peg3;
        private System.Windows.Forms.Button btnShowHistory;
        private System.Windows.Forms.Label lblDiscNPegN;
        private System.Windows.Forms.Label lblhistory;
    }
}